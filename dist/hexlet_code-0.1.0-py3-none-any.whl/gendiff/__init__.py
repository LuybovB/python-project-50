def diff_with_formatter():
    return None