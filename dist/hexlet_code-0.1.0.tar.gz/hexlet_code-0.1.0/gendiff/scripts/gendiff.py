from gendiff.diff_with_formatter import generate_diff
from gendiff.cli import generate_parser


def main():
    parser = generate_parser()
    args = parser.parse_args()
    print(generate_diff(args.first_file, args.second_file))


if __name__ == '__main__':
    main()
