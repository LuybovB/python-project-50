### Hexlet tests and linter status:
[![Actions Status](https://github.com/LuybovB/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LuybovB/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8b681e01fd1b466c96f2/maintainability)](https://codeclimate.com/github/LuybovB/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/8b681e01fd1b466c96f2/test_coverage)](https://codeclimate.com/github/LuybovB/python-project-50/test_coverage)
